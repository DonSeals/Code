import java.util.Arrays;

public class Complexity {

	public static void main(String args[]) {

		int[] array = { 10, 20, 30, 40, 50, 60, 70, 80 };

		//Constant Time Complexity (O(1))
		int element = array[2]; // This operation takes constant time O(1)
		System.out.println("Element at index 2: " + element);

		//Linear Time Complexity (O(n))
		int sum = 0;
		for (int i = 0; i < array.length; i++) { 
			// This loop runs n times where n is the length of the array
			sum += array[i];
		}
		System.out.println("Sum of array elements: " + sum);
		
		//Quadratic Time Complexity (O(n^2))
		for (int i = 0; i < array.length; i++) {               // Outer loop runs n times
            for (int j = 0; j < array.length; j++) {           // Inner loop runs n times for each iteration of the outer loop
            	System.out.println("Element: " + i + ", " + j); // Total iterations = n * n = n^2
            }
        }
		
		//Logarithmic Time Complexity (O(log n))
		int key = 30;
        int index = Arrays.binarySearch(array, key);  
        // This operation has logarithmic time complexity O(log n)
        if (index >= 0) {
            System.out.println("Element found at index: " + index);
        } else {
            System.out.println("Element not found");
        }
	}

}
