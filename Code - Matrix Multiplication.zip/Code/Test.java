
public class Test {

	public static void main(String[] args) {
		int[][] A = {{1, 2}, 
				     {3, 4}};
		int[][] B = {{5, 6}, 
				     {7, 8}};
		 //int[][] result = StandartMatrixMultiplication.multiplyMatrices(A, B);
		 //int[][] result = DivideAndConquerMultiplication.multiplyMatrices(A, B);
		 int[][] result = StrassenMultiplication.multiplyMatrices(A, B);
		
		for (int[] row : result) {
			for (int val : row) {
				System.out.print(val + " ");
			}
			System.out.println();
		}
	}
}
